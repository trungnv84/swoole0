       _____                       _____  ____ 
      |  __ \                     |  __ \|  _ \ 
      | |__) |__ ___   _____ _ __ | |  | | |_) |
      |  _  // _` \ \ / / _ \ '_ \| |  | |  _ < 
      | | \ \ (_| |\ V /  __/ | | | |__| | |_) |
      |_|  \_\__,_| \_/ \___|_| |_|_____/|____/ 



Your RavenDB cluster settings, certificate and configuration are contained in this zip file.

The new server is available at: https://a.omg-v1.ravendb.community
The current node ('A') has already been configured and requires no further action on your part.

An administrator client certificate has been installed on this machine (DESKTOP-D1DUT10).
You can now restart the server and access the studio at https://a.omg-v1.ravendb.community.
Chrome will let you select this certificate automatically. 
If it doesn't, you will get an authentication error. Please restart all instances of Chrome to make sure nothing is cached.
If you are using Firefox (or Chrome under Linux), the certificate must be imported manually to the browser.
You can do that via: Tools > Options > Advanced > 'Certificates: View Certificates'.

It is recommended to generate additional certificates with reduced access rights for applications and users.
This can be done using the RavenDB Studio, in the 'Manage Server' > 'Certificates' page.
